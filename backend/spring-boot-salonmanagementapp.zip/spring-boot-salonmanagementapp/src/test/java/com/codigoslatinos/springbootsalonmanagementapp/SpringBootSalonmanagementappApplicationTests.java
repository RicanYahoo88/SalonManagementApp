package com.codigoslatinos.springbootsalonmanagementapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSalonmanagementappApplicationTests {

	@Test
	void contextLoads() {
	}

}
